


export default function Rewards(){
    return <h1>rewards</h1>
}
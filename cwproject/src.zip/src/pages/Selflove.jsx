



export default function Selflove(){
    return <h1>Selflove</h1>
}
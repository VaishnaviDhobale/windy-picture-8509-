
export default function Harecare(){
    return <h1>harecare</h1>
}

export default function Offres(){
    return <h1>offres</h1>
}
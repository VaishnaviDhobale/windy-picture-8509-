

export default function Sanitizingcare(){
    return <h1>sanitizingcare</h1>
}

export default function Skincare(){
    return <h1>skincare</h1>
}
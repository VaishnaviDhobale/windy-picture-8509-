


export default function Collection(){
    return <h1>collections</h1>
}